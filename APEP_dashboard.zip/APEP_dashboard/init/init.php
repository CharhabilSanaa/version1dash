<?php


  DEFINE('HOST', '192.168.0.171:4045');
  DEFINE('USER', 'user_wallet');
  DEFINE('PSWD', 'wallet!22@');
  DEFINE('DATABASE', 'apep_wallet_mobile');


  
?>