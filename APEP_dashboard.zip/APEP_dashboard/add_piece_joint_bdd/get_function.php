<?php

include("../init/init.php");
include("../init/connexion.php");


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_date_courant_csv($date_courant)
{		
		list($date_courant,$heur_courant) = explode(' ', $date_courant);	
		list($jour,$mois,$annee) = explode('/', $date_courant);			
		return date('Y-m-d',mktime(date("H"), date('i'), date('s'), $mois,$jour,$annee));
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_date_courant($date_courant)
{	
		list($jour,$mois,$annee) = explode('/', $date_courant);			
		return date('Y-m-d',mktime(date("H"), date('i'), date('s'), $mois,$jour,$annee));
}


 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 function importer_data_piece_joint_csv_vers_bdd($fichier,$date_courant,$libelle)
 {

        $conn = ma_db_connexion();
	    //fichier :  repertoire + libelle : nom de la table + date courante

		//$file = glob("../recupere_piece_joint_mail/csv_files/".$fichier."/".$libelle."*.csv"); 
        $file = $fichier;
	    $table = $libelle;              
        $table = strtolower($table);
        $indexdate = array();
        
        // get structure from csv and insert db
        ini_set('auto_detect_line_endings',TRUE);
        $handle = fopen($file,'r');
        // first row, structure for date
        if ( ($data = fgetcsv($handle) ) === FALSE ) {
            echo "Cannot read from csv $file";die();
        }

        //chercher les index des dates pour la convertion
        $fields = array();
        $field_count = 0;
        for($i=0;$i<count($data); $i++) {
            $f = strtolower(trim($data[$i]));
            if ($f) {
                // normalize the field name, strip to 20 chars if too long
                $f = substr(preg_replace ('/[^0-9a-z]/', '_', $f), 0, 20);
                
                if (strpos($f, 'date') !== false) {
        
                    array_push($indexdate, $field_count);
        
                } 
        
                $field_count++;
                $fields[] = $f.' VARCHAR(50)';
            }
        }
                
        
        while ( ($data = fgetcsv($handle) ) !== FALSE ) {
            $fields = array();
            for($i=0;$i<$field_count; $i++) {
        
                if(in_array($i,$indexdate)){

                    if(empty($data[$i])){
                        $fields[] = 'NULL';
                    }
                    else{

                    
                        $data[$i] = str_replace('/','-', $data[$i]);
                        $timestamp = strtotime($data[$i]);
                        $date = date("Y-m-d H:i:s", $timestamp);
                        $fields[] = '\''.$date.'\''; 

                    }
                    
        
                }else{

                    $fields[] = '\''.addslashes($data[$i]).'\'';
                }
                
                
        
            }

            date_default_timezone_set('Europe/Berlin');
            $date = date('Y-m-d H:i:s');
            $fields[] = '\''.$date.'\''; 

            $sqldeleteid ="ALTER TABLE $table  DROP id";
            if (mysqli_query($conn, $sqldeleteid)) {
                echo "New record created successfully";
            } 
            
            else {
                echo "Error: " . $sqldeleteid . "<br>" . mysqli_error($conn);
            }


            $sql = "Insert into $table values(" . implode(', ', $fields) . ')';
            if (mysqli_query($conn, $sql)) {
                echo "New record created successfully";
              } else {
                echo "Error: " . $sql . "<br>" . mysqli_error($conn);
              }
            
            }
            fclose($handle);
            ini_set('auto_detect_line_endings',FALSE);

            $sqlid = "ALTER TABLE $table ADD id INT NOT NULL AUTO_INCREMENT PRIMARY KEY FIRST";
           
            if (mysqli_query($conn, $sqlid)) {
                echo "id added ";
            } else {
                echo "Error: " . $sql . "<br>" . mysqli_error($conn);
            }
            
    }
    mysqli_close($conn);
		

     //for homologations :---------------------------------
    /**$servername = "192.168.0.171:4045";
$username = "user_wallet";
$password = "wallet!22@";
$dbname = "apep_wallet_mobile";


// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}


//read rows:
$row = 1;
if (($handle = fopen("ETAT-HOMOLOGATION-MEMBRES.csv", "r")) !== FALSE) {
    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        
        
        $num = count($data); 
        $payeur=array();
        $paye=array();
        
        if ($row>16 AND $row<25) {
            for ($c=0; $c < $num; $c++) {
                $payeur[] = '\''.addslashes($data[$c]).'\'';
            }
            $sqlpayeur = "Insert into hom_payeur values(" . implode(', ', $payeur) . ')';
            
                if (mysqli_query($conn, $sqlpayeur)) {
                    echo "New record created successfully";
                } else {
                    echo "Error: " . $sqlpayeur . "<br>" . mysqli_error($conn);
                }
            $row++;
        }
        elseif  ($row>43 AND $row<52) {
            for ($c=0; $c < $num; $c++) {

                $paye[] = '\''.addslashes($data[$c]).'\'';

            }
            $sqlpaye = "Insert into hom_paye values(" . implode(', ', $paye) . ')';

                if (mysqli_query($conn, $sqlpaye)) {
                    echo "New record created successfully";
                } else {
                    echo "Error: " . $sqlpaye . "<br>" . mysqli_error($conn);
                }
            $row++;
        }
        else{
            $row++;
        }
        
    }
}


            
          
ini_set('auto_detect_line_endings',FALSE); */

/**
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */

?>

